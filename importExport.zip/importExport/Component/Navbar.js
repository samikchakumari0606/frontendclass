function Navbar(){
    return `<p>Home</p>
    <p>About</p>
    <p>Contact</p>
    <p>Login & Signup</p>`
}
export default Navbar;