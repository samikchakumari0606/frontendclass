
import Navbar from "./Component/Navbar.js"
console.log(Navbar)

let myNav=document.getElementById("navbar");
myNav.innerHTML=Navbar();