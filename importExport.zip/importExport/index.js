
import Navbar from "./Component/Navbar.js";
console.log(Navbar);

let navDiv=document.getElementById("navbar");
navDiv.innerHTML=Navbar();


// youtube
// weather 
// hotstar
// flipkart
// slideshow